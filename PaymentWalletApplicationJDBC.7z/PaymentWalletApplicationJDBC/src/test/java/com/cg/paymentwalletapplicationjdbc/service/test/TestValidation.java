package com.cg.paymentwalletapplicationjdbc.service.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.paymentwalletapplicationjdbc.dao.IPaymentDao;
import com.cg.paymentwalletapplicationjdbc.dao.PaymentDaoImpl;
import com.cg.paymentwalletapplicationjdbc.dto.Wallet;
import com.cg.paymentwalletapplicationjdbc.exception.PaymentException;
import com.cg.paymentwalletapplicationjdbc.service.IPaymentService;
import com.cg.paymentwalletapplicationjdbc.service.PaymentServiceImpl;


public class TestValidation {
	IPaymentService service=new PaymentServiceImpl();
	IPaymentDao dao=new PaymentDaoImpl();
		@Test
		public void CheckForZeroDeposittest() throws PaymentException {
			boolean condition=false;
			Wallet wallet=new Wallet();
			wallet.setUserId("7095804719");
			dao.createAccount(wallet);
			condition=service.deposit("7095804719", 0.0);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidDepositAmount() throws PaymentException {
			boolean condition=false;
			Wallet wallet=new Wallet();
			wallet.setUserId("7095804719");
			dao.createAccount(wallet);
			condition=service.deposit("7095804719", 500);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidNameTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("fd65f46");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priyanka@gmail.com");
			wallet.setUserId("priyanka");
			wallet.setPassword("12345678");
			service.validateDetails(wallet);
		}
		
		@Test
		public void CheckForValidNameTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priyanka@gmail.com");
			wallet.setUserId("priyanka");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidPhoneNumberTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095809");
			wallet.setEmailId("priyanka@gmail.com");
			wallet.setUserId("priyanka");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidPhoneNumberTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priyanka@gmail.com");
			wallet.setUserId("priyanka");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidEmailTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("4gfgaff");
			wallet.setUserId("priyanka");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidEmailTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priyanka@gmail.com");
			wallet.setUserId("priyanka");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}

		@Test (expected=PaymentException.class)
		public void CheckForInvalidUserId() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priyanka@gmail.com");
			wallet.setUserId("priyan6594@ni");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
			
		}
		
		@Test 
		public void CheckForValidUserId() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priyanka@gmail.com");
			wallet.setUserId("priyanka");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
			
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidpassword() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priyanka@gmail.com");
			wallet.setUserId("priyanka");
			wallet.setPassword("12345");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
			
		}
		
		@Test 
		public void CheckForValidPassword() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priyanka@gmail.com");
			wallet.setUserId("priyanka");
			wallet.setPassword("12345678");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
			
		}


}
